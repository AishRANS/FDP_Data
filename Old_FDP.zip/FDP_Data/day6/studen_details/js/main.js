$(document).ready(function() {
    alert("ready");
    //  $("#hide").click(function() {
    //    $("#data").hide();
    //});
    //$("#show").click(function() {
    //  $("#data").show();
    //});
    // $("#toggle").click(function() {
    //   $("#data").fadeToggleIn();
    //});

});