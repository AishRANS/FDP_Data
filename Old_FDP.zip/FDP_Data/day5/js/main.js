function drawtable() {
    var row = parseInt(prompt("how many row"));
    var cols = parseInt(prompt("how many column"));
    //var row_t = "<h1>row:" + row + "</h1>";
    //var cols_t = "<h1>column:" + cols + "</h1>";
    var html = "<h1>row:" + row + "</h1>";
    html += "<h1>column:" + cols + "</h1>";
    html += "<table border= '2'>";

    //document.write(row_t);
    //document.write(cols_t);
    //row= parseInt(row);
    for (var i = 1; i <= row; i++) {
        html += "<tr>";
        for (var j = 1; j <= cols; j++) {
            //html += "<td> row:" + i + "; column:" + j + "</td>";
            /*  if ((i + j) % 2 != 0) {
                  document.write("<td bgcolor='white'></td>");
              }
              else {
                  document.write("<td bgcolor='black'></td>");
              }*/
            if (i % 2 == 1) {
                if (j % 2 == 1) {
                    html += "<td bgcolor='green'> row:" + i + "; column:" + j + "</td>";
                } else {
                    html += "<td> row:" + i + "; column:" + j + "</td>";
                }
            } else {
                if (j % 2 == 0) {
                    html += "<td bgcolor='black'> row:" + i + "; column:" + j + "</td>";
                } else {
                    html += "<td> row:" + i + "; column:" + j + "</td>";
                }

            }

        }
        html += "</tr>";
    }
    html += "</table>";
    document.getElementById('draw').innerHTML = html;
    document.write(html);
}
//console.log(row);
//console.log(cols);
// document.getElementById("row_t").innerHTML = row;
//document.getElementById("cols_t").innerHTML = cols;